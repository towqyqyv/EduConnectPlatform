import React from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { LogOut, ChevronRight } from 'lucide-react';

interface SidebarProps {
  isMobile?: boolean;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isMobile, onClose }) => {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navItems = [
    { path: '/dashboard', icon: 'dashboard', label: 'Dashboard' },
    { path: '/study-groups', icon: 'groups', label: 'Study Groups' },
    { path: '/discussions', icon: 'forum', label: 'Discussions' },
    { path: '/resources', icon: 'library_books', label: 'Resources' },
    { path: '/sessions', icon: 'event', label: 'Schedule' },
    { path: '/notifications', icon: 'notifications', label: 'Notifications', badge: 3 },
  ];

  return (
    <aside className={`flex flex-col bg-white border-r border-neutral-200 h-full ${isMobile ? 'w-64' : 'hidden md:flex md:w-64'}`}>
      <div className="p-4 border-b border-neutral-200">
        <div className="flex items-center space-x-3">
          {isMobile && (
            <button
              onClick={onClose}
              className="md:hidden text-neutral-500 hover:text-neutral-700"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          )}
          <div className="bg-primary rounded-lg w-10 h-10 flex items-center justify-center">
            <span className="material-icons text-white">school</span>
          </div>
          <h1 className="font-heading font-semibold text-xl text-primary">EduConnect</h1>
        </div>
      </div>
      
      {/* User Info */}
      <div className="p-4 border-b border-neutral-200">
        <div className="flex items-center space-x-3">
          <div className="bg-neutral-200 rounded-full w-10 h-10 flex items-center justify-center">
            <span className="material-icons text-neutral-600">person</span>
          </div>
          <div>
            <p className="font-medium text-sm">{user?.username}</p>
            <p className="text-xs text-neutral-500">{user?.role}</p>
          </div>
        </div>
      </div>

      {/* Nav Links */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul>
          {navItems.map((item) => (
            <li key={item.path}>
              <Link href={item.path}>
                <a 
                  className={`flex items-center px-4 py-3 ${
                    location === item.path 
                      ? 'text-primary bg-primary bg-opacity-10 font-medium' 
                      : 'text-neutral-700 hover:bg-neutral-100'
                  } transition-colors`}
                >
                  <span className="material-icons mr-3">{item.icon}</span>
                  {item.label}
                  {item.badge && (
                    <span className="ml-auto bg-primary text-white text-xs px-2 py-1 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* Logout Button */}
      <div className="p-4 border-t border-neutral-200">
        <button 
          onClick={handleLogout}
          className="flex items-center text-neutral-700 hover:text-primary transition-colors w-full"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
