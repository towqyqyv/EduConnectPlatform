import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Clock, Loader2, Plus, UserPlus, Users, Video, ExternalLink, Calendar as CalendarCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';

const createSessionSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(100, "Title must be less than 100 characters"),
  description: z.string().optional(),
  date: z.string().min(1, "Date is required"),
  duration: z.coerce.number().min(15, "Duration must be at least 15 minutes").max(240, "Duration must be less than 4 hours"),
  platform: z.string().min(1, "Platform is required"),
  meetingUrl: z.string().url("Please enter a valid URL").optional().or(z.literal("")),
  groupId: z.string().min(1, "Study group is required"),
});

const onSubmit = async (data: z.infer<typeof createSessionSchema>) => {
  try {
    const sessionDate = new Date(data.date);
    if (sessionDate < new Date()) {
      toast({
        title: "Invalid date",
        description: "Session date must be in the future",
        variant: "destructive"
      });
      return;
    }

    const response = await createSessionMutation.mutateAsync({
      title: data.title,
      description: data.description || null,
      date: sessionDate.toISOString(),
      duration: data.duration,
      platform: data.platform,
      meetingUrl: data.meetingUrl || null,
      status: 'scheduled',
      hostId: user!.id,
      groupId: parseInt(data.groupId)
    });

    if (response) {
      setIsCreateDialogOpen(false);
      form.reset();
      queryClient.invalidateQueries(['sessions']);
      toast({
        title: "Success",
        description: "Session scheduled successfully",
      });
    }
  } catch (error) {
    console.error('Failed to create session:', error);
    toast({
      title: "Error",
      description: "Failed to create session. Please try again.",
      variant: "destructive"
    });
  }
};

type CreateSessionForm = z.infer<typeof createSessionSchema>;

export default function SessionsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('upcoming');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const isTeacher = user?.role === 'teacher';

  // Fetch joined study groups
  const { data: joinedGroups, isLoading: loadingGroups } = useQuery({
    queryKey: ['/api/study-groups/joined'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch joined groups');
      return res.json();
    },
  });

  // Fetch upcoming sessions
  const { data: upcomingSessions, isLoading: loadingSessions } = useQuery({
    queryKey: ['/api/sessions/upcoming'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch upcoming sessions');
      return res.json();
    },
  });

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: {
      title: string;
      description: string | null;
      date: string;
      duration: number;
      platform: string;
      meetingUrl: string | null;
      groupId: number;
      status: string;
      hostId: number;
    }) => {
      const res = await apiRequest('POST', '/api/sessions', sessionData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions/upcoming'] });
      toast({
        title: 'Session created',
        description: 'Your study session has been scheduled successfully',
      });
      setIsCreateDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to create session',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Join session mutation
  const joinSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      const res = await apiRequest('POST', `/api/sessions/${sessionId}/join`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions/upcoming'] });
      toast({
        title: 'Session joined',
        description: 'You have successfully joined the session',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to join session',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Form for creating a session
  const form = useForm<CreateSessionForm>({
    resolver: zodResolver(createSessionSchema),
    defaultValues: {
      title: '',
      description: '',
      date: '',
      time: '',
      duration: 60,
      platform: '',
      meetingUrl: '',
      groupId: '',
    },
  });

  // Handle form submission for creating a session
  const onSubmit = (data: CreateSessionForm) => {
    // Check if user is a teacher
    if (user?.role !== 'teacher') {
      toast({
        title: 'Permission denied',
        description: 'Only teachers can create study sessions',
        variant: 'destructive',
      });
      return;
    }

    // Combine date and time into a single Date object
    const [hours, minutes] = data.time.split(':').map(Number);
    const sessionDate = new Date(data.date);
    sessionDate.setHours(hours, minutes);

    const sessionData = {
      title: data.title,
      description: data.description || null,
      date: sessionDate.toISOString(),
      duration: data.duration,
      platform: data.platform,
      meetingUrl: data.meetingUrl || null,
      groupId: parseInt(data.groupId),
      status: 'scheduled',
      hostId: user?.id,
    };

    createSessionMutation.mutate(sessionData);
  };

  // Handle joining a session
  const handleJoinSession = (sessionId: string) => {
    joinSessionMutation.mutate(sessionId);
  };

  // Format date and time for display
  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, "EEE, MMM d, yyyy 'at' h:mm a");
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, "h:mm a");
  };

  // Check if the session is hosted by the current user
  const isSessionHost = (hostId: number) => {
    return user?.id === hostId;
  };

  // Check if the user is already a participant in the session
  const isParticipant = (session: any) => {
    return session.participants?.some((p: any) => p.userId === user?.id) || isSessionHost(session.hostId);
  };

  const isLoading = loadingGroups || loadingSessions;
  const isPending = createSessionMutation.isPending || joinSessionMutation.isPending;

  return (
    <Layout title="Session Scheduling">
      <div className="max-w-7xl mx-auto space-y-6 pb-20">
        {/* Header Section */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-2xl font-bold">Study Sessions</h2>
                <CardDescription>
                  Schedule and join virtual study sessions with your groups
                </CardDescription>
              </div>

              {isTeacher && (
                <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="h-4 w-4 mr-2" />
                      Schedule Session
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>Schedule New Study Session</DialogTitle>
                      <DialogDescription>
                        Create a virtual study session for your group. Fill in all required details.
                      </DialogDescription>
                    </DialogHeader>

                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
                        <FormField
                          control={form.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Session Title *</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. Chapter 5 Review" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Brief description of what will be covered..." 
                                  className="resize-none"
                                  {...field}
                                  value={field.value || ''}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="date"
                            render={({ field }) => (
                              <FormItem className="flex flex-col">
                                <FormLabel>Date *</FormLabel>
                                <Popover>
                                  <PopoverTrigger asChild>
                                    <FormControl>
                                      <Button
                                        variant="outline"
                                        className="pl-3 text-left font-normal"
                                        disabled={loadingGroups}
                                      >
                                        {field.value ? (
                                          format(new Date(field.value), "MMM d yyyy")
                                        ) : (
                                          <span>Pick a date</span>
                                        )}
                                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                      </Button>
                                    </FormControl>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                      mode="single"
                                      selected={field.value ? new Date(field.value) : null}
                                      onSelect={(date) => field.onChange(format(date, 'yyyy-MM-dd'))}
                                      initialFocus
                                      disabled={(date) => date < new Date()}
                                    />
                                  </PopoverContent>
                                </Popover>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="time"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Time *</FormLabel>
                                <FormControl>
                                  <Input type="time" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="duration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Duration (minutes) *</FormLabel>
                              <FormControl>
                                <Input type="number" min="15" max="240" step="15" {...field} />
                              </FormControl>
                              <FormDescription>
                                Enter duration in minutes (15-240)
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="platform"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Platform *</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select platform" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Google Meet">Google Meet</SelectItem>
                                  <SelectItem value="Zoom">Zoom</SelectItem>
                                  <SelectItem value="Microsoft Teams">Microsoft Teams</SelectItem>
                                  <SelectItem value="Other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="meetingUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Meeting URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://meet.google.com/..." {...field} value={field.value || ''} />
                              </FormControl>
                              <FormDescription>
                                Add the meeting link if available now, or update later
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="groupId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Study Group *</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select study group" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {loadingGroups ? (
                                    <div className="flex justify-center p-2">
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    </div>
                                  ) : joinedGroups?.length > 0 ? (
                                    joinedGroups.map((group) => (
                                      <SelectItem key={group.id} value={group.id.toString()}>
                                        {group.name}
                                      </SelectItem>
                                    ))
                                  ) : (
                                    <div className="p-2 text-center text-sm text-muted-foreground">
                                      No study groups joined
                                    </div>
                                  )}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <DialogFooter>
                          <Button 
                            type="submit" 
                            disabled={isPending}
                          >
                            {isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Scheduling...
                              </>
                            ) : (
                              "Schedule Session"
                            )}
                          </Button>
                        </DialogFooter>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Sessions Tabs and Display */}
        <Tabs defaultValue="upcoming" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="upcoming">Upcoming Sessions</TabsTrigger>
            <TabsTrigger value="hosted">Hosted by Me</TabsTrigger>
            <TabsTrigger value="past">Past Sessions</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-6 space-y-6">
            {isLoading ? (
              <div className="flex justify-center py-10">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
              </div>
            ) : upcomingSessions?.length > 0 ? (
              <>
                {/* Calendar View (simplified) */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CalendarCheck className="h-5 w-5 mr-2" />
                      Sessions Calendar
                    </CardTitle>
                    <CardDescription>
                      Visual overview of your upcoming study sessions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-neutral-50 p-4 rounded-md border border-dashed border-neutral-300 text-center">
                      <p className="text-sm text-muted-foreground">
                        Calendar view would display sessions here in a real implementation.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Sessions List */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {upcomingSessions
                    .filter(session => {
                      if (activeTab === 'hosted') return isSessionHost(session.hostId);
                      if (activeTab === 'past') return new Date(session.date) < new Date();
                      return new Date(session.date) >= new Date(); // upcoming
                    })
                    .map((session) => (
                      <Card key={session.id} className="overflow-hidden">
                        <div className={`p-2 ${
                          session.platform === 'Google Meet' ? 'bg-blue-500' : 
                          session.platform === 'Zoom' ? 'bg-blue-600' : 
                          session.platform === 'Microsoft Teams' ? 'bg-purple-600' : 'bg-primary'
                        } text-white`}>
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">{session.platform}</span>
                            <Badge variant="outline" className="text-white border-white/50">
                              {session.status}
                            </Badge>
                          </div>
                        </div>

                        <CardHeader className="pb-2">
                          <CardTitle>{session.title}</CardTitle>
                          <CardDescription>
                            {session.groupName} • Hosted by {session.hostName}
                          </CardDescription>
                        </CardHeader>

                        <CardContent>
                          {session.description && (
                            <p className="text-sm text-muted-foreground mb-4">
                              {session.description}
                            </p>
                          )}

                          <div className="space-y-2">
                            <div className="flex items-center text-sm">
                              <CalendarIcon className="h-4 w-4 mr-2 text-muted-foreground" />
                              <span>{formatDateTime(session.date)}</span>
                            </div>

                            <div className="flex items-center text-sm">
                              <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                              <span>{session.duration} minutes</span>
                            </div>

                            <div className="flex items-center text-sm">
                              <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                              <span>{session.participantCount || 0} participants</span>
                            </div>
                          </div>
                        </CardContent>

                        <CardFooter className="border-t pt-4 flex justify-between">
                          {session.meetingUrl ? (
                            <a 
                              href={session.meetingUrl} 
                              target="_blank" 
                              rel="noopener noreferrer" 
                              className="inline-flex items-center"
                            >
                              <Button variant="outline" size="sm">
                                <ExternalLink className="h-4 w-4 mr-2" />
                                Meeting Link
                              </Button>
                            </a>
                          ) : (
                            <span className="text-sm text-muted-foreground">
                              Meeting link will be added soon
                            </span>
                          )}

                          {!isSessionHost(session.hostId) && !isParticipant(session) && (
                            <Button 
                              onClick={() => handleJoinSession(session.id.toString())}
                              disabled={joinSessionMutation.isPending}
                              size="sm"
                            >
                              {joinSessionMutation.isPending ? (
                                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              ) : (
                                <UserPlus className="h-4 w-4 mr-2" />
                              )}
                              Join Session
                            </Button>
                          )}

                          {isSessionHost(session.hostId) && (
                            <Button variant="outline" size="sm">
                              <Video className="h-4 w-4 mr-2" />
                              Start Session
                            </Button>
                          )}

                          {!isSessionHost(session.hostId) && isParticipant(session) && (
                            <Badge variant="outline" className="ml-auto">
                              Joined
                            </Badge>
                          )}
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </>
            ) : (
              <div className="text-center py-20 border rounded-lg bg-white">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <CalendarCheck className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-medium">No sessions found</h3>
                <p className="text-muted-foreground mt-1 mb-6">
                  {activeTab === 'upcoming' 
                    ? 'There are no upcoming study sessions scheduled.'
                    : activeTab === 'hosted'
                      ? 'You haven\'t hosted any study sessions yet.'
                      : 'There are no past study sessions to display.'}
                </p>
                {isTeacher && (
                  <Button onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Schedule Your First Session
                  </Button>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}