import {
  User, InsertUser,
  StudyGroup, InsertStudyGroup,
  GroupMember, InsertGroupMember,
  Message, InsertMessage,
  Resource, InsertResource,
  Session, InsertSession,
  SessionParticipant, InsertSessionParticipant,
  Notification, InsertNotification,
  Activity, InsertActivity,
  // Import tables for database access
  users, studyGroups, groupMembers, messages, resources,
  sessions, sessionParticipants, notifications, activities
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, gte, desc, sql } from "drizzle-orm";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

interface ExtendedUser extends User {
  fullName?: string;
}

interface ExtendedStudyGroup extends StudyGroup {
  memberCount?: number;
  createdByUsername?: string;
  nextSession?: string;
}

interface ExtendedMessage extends Message {
  username?: string;
}

interface ExtendedResource extends Resource {
  groupName?: string;
  uploadedByUsername?: string;
}

interface ExtendedSession extends Session {
  groupName?: string;
  hostName?: string;
  participantCount?: number;
}

// Define the storage interface with CRUD methods
export interface IStorage {
  // Session store
  sessionStore: session.SessionStore;

  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Study Groups
  getAllStudyGroups(): Promise<ExtendedStudyGroup[]>;
  getStudyGroup(id: number): Promise<StudyGroup | undefined>;
  getStudyGroupByName(name: string): Promise<StudyGroup | undefined>;
  getJoinedStudyGroups(userId: number): Promise<ExtendedStudyGroup[]>;
  getCreatedStudyGroups(userId: number): Promise<ExtendedStudyGroup[]>;
  createStudyGroup(group: InsertStudyGroup): Promise<StudyGroup>;
  isGroupMember(userId: number, groupId: number): Promise<boolean>;
  addMemberToGroup(userId: number, groupId: number): Promise<GroupMember>;
  getGroupMembers(groupId: number): Promise<GroupMember[]>;

  // Messages
  getGroupMessages(groupId: number): Promise<ExtendedMessage[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // Resources
  getUserAccessibleResources(userId: number): Promise<ExtendedResource[]>;
  createResource(resource: InsertResource): Promise<Resource>;

  // Sessions
  getUpcomingSessions(userId: number): Promise<ExtendedSession[]>;
  getSession(id: number): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  isSessionParticipant(sessionId: number, userId: number): Promise<boolean>;
  addSessionParticipant(participant: InsertSessionParticipant): Promise<SessionParticipant>;

  // Notifications
  getUserNotifications(userId: number): Promise<Notification[]>;
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<void>;

  // Activities
  getUserRelevantActivities(userId: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

// In-memory implementation of the storage interface
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private studyGroups: Map<number, StudyGroup>;
  private groupMembers: Map<number, GroupMember>;
  private messages: Map<number, Message>;
  private resources: Map<number, Resource>;
  private sessions: Map<number, Session>;
  private sessionParticipants: Map<number, SessionParticipant>;
  private notifications: Map<number, Notification>;
  private activities: Map<number, Activity>;
  private userIds: { [key: string]: number } = {}; // username to id mapping
  private userEmailIds: { [key: string]: number } = {}; // email to id mapping
  private groupNameIds: { [key: string]: number } = {}; // group name to id mapping
  sessionStore: session.SessionStore;

  private userIdCounter: number = 1;
  private groupIdCounter: number = 1;
  private memberIdCounter: number = 1;
  private messageIdCounter: number = 1;
  private resourceIdCounter: number = 1;
  private sessionIdCounter: number = 1;
  private participantIdCounter: number = 1;
  private notificationIdCounter: number = 1;
  private activityIdCounter: number = 1;

  constructor() {
    this.users = new Map();
    this.studyGroups = new Map();
    this.groupMembers = new Map();
    this.messages = new Map();
    this.resources = new Map();
    this.sessions = new Map();
    this.sessionParticipants = new Map();
    this.notifications = new Map();
    this.activities = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });

    // Add seed data for demo purposes
    this.seedData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const userId = this.userIds[username];
    if (userId) {
      return this.users.get(userId);
    }
    return undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const userId = this.userEmailIds[email];
    if (userId) {
      return this.users.get(userId);
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    this.userIds[user.username] = id;
    this.userEmailIds[user.email] = id;
    return user;
  }

  // Study Group methods
  async getAllStudyGroups(): Promise<ExtendedStudyGroup[]> {
    const groups = Array.from(this.studyGroups.values());
    
    return groups.map(group => {
      const memberCount = this.getGroupMemberCount(group.id);
      const createdByUser = this.users.get(group.createdBy);
      
      return {
        ...group,
        memberCount,
        createdByUsername: createdByUser?.username || "Unknown User"
      };
    });
  }

  async getStudyGroup(id: number): Promise<StudyGroup | undefined> {
    return this.studyGroups.get(id);
  }

  async getStudyGroupByName(name: string): Promise<StudyGroup | undefined> {
    const groupId = this.groupNameIds[name];
    if (groupId) {
      return this.studyGroups.get(groupId);
    }
    return undefined;
  }

  async getJoinedStudyGroups(userId: number): Promise<ExtendedStudyGroup[]> {
    const memberships = Array.from(this.groupMembers.values())
      .filter(member => member.userId === userId);
    
    const groups: ExtendedStudyGroup[] = [];
    
    for (const membership of memberships) {
      const group = this.studyGroups.get(membership.groupId);
      if (group) {
        const memberCount = this.getGroupMemberCount(group.id);
        const createdByUser = this.users.get(group.createdBy);
        
        // Get the next scheduled session for this group
        const upcomingSessions = Array.from(this.sessions.values())
          .filter(session => 
            session.groupId === group.id && 
            new Date(session.date) > new Date()
          )
          .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        
        const nextSession = upcomingSessions.length > 0 
          ? this.formatSessionDateTime(upcomingSessions[0].date)
          : undefined;
        
        groups.push({
          ...group,
          memberCount,
          createdByUsername: createdByUser?.username || "Unknown User",
          nextSession
        });
      }
    }
    
    return groups;
  }

  async getCreatedStudyGroups(userId: number): Promise<ExtendedStudyGroup[]> {
    const groups = Array.from(this.studyGroups.values())
      .filter(group => group.createdBy === userId);
    
    return groups.map(group => {
      const memberCount = this.getGroupMemberCount(group.id);
      return {
        ...group,
        memberCount,
        createdByUsername: this.users.get(group.createdBy)?.username || "Unknown User"
      };
    });
  }

  async createStudyGroup(insertGroup: InsertStudyGroup): Promise<StudyGroup> {
    const id = this.groupIdCounter++;
    const group: StudyGroup = { ...insertGroup, id, createdAt: new Date() };
    this.studyGroups.set(id, group);
    this.groupNameIds[group.name] = id;
    return group;
  }

  async isGroupMember(userId: number, groupId: number): Promise<boolean> {
    return Array.from(this.groupMembers.values())
      .some(member => member.userId === userId && member.groupId === groupId);
  }

  async addMemberToGroup(userId: number, groupId: number): Promise<GroupMember> {
    const id = this.memberIdCounter++;
    const member: GroupMember = {
      id,
      userId,
      groupId,
      joinedAt: new Date()
    };
    this.groupMembers.set(id, member);
    return member;
  }

  async getGroupMembers(groupId: number): Promise<GroupMember[]> {
    return Array.from(this.groupMembers.values())
      .filter(member => member.groupId === groupId);
  }

  // Message methods
  async getGroupMessages(groupId: number): Promise<ExtendedMessage[]> {
    const messages = Array.from(this.messages.values())
      .filter(message => message.groupId === groupId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    
    return messages.map(message => {
      const user = this.users.get(message.userId);
      return {
        ...message,
        username: user?.username || "Unknown User"
      };
    });
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const message: Message = { ...insertMessage, id, timestamp: new Date() };
    this.messages.set(id, message);
    return message;
  }

  // Resource methods
  async getUserAccessibleResources(userId: number): Promise<ExtendedResource[]> {
    // Get groups the user is a member of
    const userGroups = Array.from(this.groupMembers.values())
      .filter(member => member.userId === userId)
      .map(member => member.groupId);
    
    // Get resources from those groups
    const resources = Array.from(this.resources.values())
      .filter(resource => userGroups.includes(resource.groupId))
      .sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
    
    return resources.map(resource => {
      const group = this.studyGroups.get(resource.groupId);
      const uploader = this.users.get(resource.uploadedBy);
      
      return {
        ...resource,
        groupName: group?.name || "Unknown Group",
        uploadedByUsername: uploader?.username || "Unknown User"
      };
    });
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const resource: Resource = { ...insertResource, id, uploadedAt: new Date() };
    this.resources.set(id, resource);
    return resource;
  }

  // Session methods
  async getUpcomingSessions(userId: number): Promise<ExtendedSession[]> {
    // Get groups the user is a member of
    const userGroups = Array.from(this.groupMembers.values())
      .filter(member => member.userId === userId)
      .map(member => member.groupId);
    
    // Get upcoming sessions for those groups
    const now = new Date();
    const sessions = Array.from(this.sessions.values())
      .filter(session => 
        userGroups.includes(session.groupId) && 
        new Date(session.date) > now
      )
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    return sessions.map(session => {
      const group = this.studyGroups.get(session.groupId);
      const host = this.users.get(session.hostId);
      const participantCount = this.getSessionParticipantCount(session.id);
      
      return {
        ...session,
        groupName: group?.name || "Unknown Group",
        hostName: host?.username || "Unknown User",
        participantCount
      };
    });
  }

  async getSession(id: number): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = this.sessionIdCounter++;
    const session: Session = { ...insertSession, id, createdAt: new Date() };
    this.sessions.set(id, session);
    return session;
  }

  async isSessionParticipant(sessionId: number, userId: number): Promise<boolean> {
    return Array.from(this.sessionParticipants.values())
      .some(participant => 
        participant.sessionId === sessionId && 
        participant.userId === userId
      );
  }

  async addSessionParticipant(insertParticipant: InsertSessionParticipant): Promise<SessionParticipant> {
    const id = this.participantIdCounter++;
    const participant: SessionParticipant = { 
      ...insertParticipant, 
      id, 
      joinedAt: new Date() 
    };
    this.sessionParticipants.set(id, participant);
    return participant;
  }

  // Notification methods
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notifications.get(id);
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.notificationIdCounter++;
    const notification: Notification = { 
      ...insertNotification, 
      id, 
      createdAt: new Date() 
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.unread = false;
      this.notifications.set(id, notification);
    }
  }

  // Activity methods
  async getUserRelevantActivities(userId: number): Promise<Activity[]> {
    // Get groups the user is a member of
    const userGroups = Array.from(this.groupMembers.values())
      .filter(member => member.userId === userId)
      .map(member => member.groupId);
    
    // Get activities from the user or related to their groups
    return Array.from(this.activities.values())
      .filter(activity => 
        activity.userId === userId || 
        (activity.relatedType === 'study_group' && userGroups.includes(activity.relatedId!))
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      timestamp: new Date() 
    };
    this.activities.set(id, activity);
    return activity;
  }

  // Helper methods
  private getGroupMemberCount(groupId: number): number {
    return Array.from(this.groupMembers.values())
      .filter(member => member.groupId === groupId)
      .length;
  }

  private getSessionParticipantCount(sessionId: number): number {
    return Array.from(this.sessionParticipants.values())
      .filter(participant => participant.sessionId === sessionId)
      .length;
  }

  private formatSessionDateTime(date: Date): string {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const sessionDate = new Date(date);
    const timeString = sessionDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    if (sessionDate.toDateString() === today.toDateString()) {
      return `Today, ${timeString}`;
    } else if (sessionDate.toDateString() === tomorrow.toDateString()) {
      return `Tomorrow, ${timeString}`;
    } else {
      return `${sessionDate.toLocaleDateString([], { weekday: 'long' })}, ${timeString}`;
    }
  }

  private seedData(): void {
    // This is just for demo purposes to show some initial data
    // In a real app, this would be replaced with actual database queries
  }
}

// PostgreSQL Database implementation of the storage interface
export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using any to avoid TypeScript errors with session.SessionStore
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Study Group methods
  async getAllStudyGroups(): Promise<ExtendedStudyGroup[]> {
    const allGroups = await db.select().from(studyGroups);
    
    // Get member counts for each group
    const extendedGroups: ExtendedStudyGroup[] = [];
    
    for (const group of allGroups) {
      const members = await db.select().from(groupMembers).where(eq(groupMembers.groupId, group.id));
      const creator = await this.getUser(group.createdBy);
      
      extendedGroups.push({
        ...group,
        memberCount: members.length,
        createdByUsername: creator?.username || "Unknown User"
      });
    }
    
    return extendedGroups;
  }

  async getStudyGroup(id: number): Promise<StudyGroup | undefined> {
    const [group] = await db.select().from(studyGroups).where(eq(studyGroups.id, id));
    return group;
  }

  async getStudyGroupByName(name: string): Promise<StudyGroup | undefined> {
    const [group] = await db.select().from(studyGroups).where(eq(studyGroups.name, name));
    return group;
  }

  async getJoinedStudyGroups(userId: number): Promise<ExtendedStudyGroup[]> {
    // Get all groups that the user is a member of
    const membershipRecords = await db
      .select()
      .from(groupMembers)
      .where(eq(groupMembers.userId, userId));
    
    const extendedGroups: ExtendedStudyGroup[] = [];
    
    for (const membership of membershipRecords) {
      const [group] = await db
        .select()
        .from(studyGroups)
        .where(eq(studyGroups.id, membership.groupId));
      
      if (group) {
        const members = await db
          .select()
          .from(groupMembers)
          .where(eq(groupMembers.groupId, group.id));
        
        const creator = await this.getUser(group.createdBy);
        
        // Get next scheduled session
        const now = new Date();
        const [nextSession] = await db
          .select()
          .from(sessions)
          .where(
            and(
              eq(sessions.groupId, group.id),
              gte(sessions.date, now)
            )
          )
          .orderBy(sessions.date)
          .limit(1);
        
        const nextSessionDate = nextSession ? this.formatSessionDateTime(nextSession.date) : undefined;
        
        extendedGroups.push({
          ...group,
          memberCount: members.length,
          createdByUsername: creator?.username || "Unknown User",
          nextSession: nextSessionDate
        });
      }
    }
    
    return extendedGroups;
  }

  async getCreatedStudyGroups(userId: number): Promise<ExtendedStudyGroup[]> {
    const createdGroups = await db
      .select()
      .from(studyGroups)
      .where(eq(studyGroups.createdBy, userId));
    
    const extendedGroups: ExtendedStudyGroup[] = [];
    
    for (const group of createdGroups) {
      const members = await db
        .select()
        .from(groupMembers)
        .where(eq(groupMembers.groupId, group.id));
      
      extendedGroups.push({
        ...group,
        memberCount: members.length,
        createdByUsername: "You" // Since this is for the creator's view
      });
    }
    
    return extendedGroups;
  }

  async createStudyGroup(group: InsertStudyGroup): Promise<StudyGroup> {
    const [newGroup] = await db.insert(studyGroups).values(group).returning();
    return newGroup;
  }

  async isGroupMember(userId: number, groupId: number): Promise<boolean> {
    const count = await db
      .select()
      .from(groupMembers)
      .where(
        and(
          eq(groupMembers.userId, userId),
          eq(groupMembers.groupId, groupId)
        )
      );
    
    return count.length > 0;
  }

  async addMemberToGroup(userId: number, groupId: number): Promise<GroupMember> {
    const [member] = await db
      .insert(groupMembers)
      .values({
        userId,
        groupId
      })
      .returning();
    
    return member;
  }

  async getGroupMembers(groupId: number): Promise<GroupMember[]> {
    return await db
      .select()
      .from(groupMembers)
      .where(eq(groupMembers.groupId, groupId));
  }

  // Message methods
  async getGroupMessages(groupId: number): Promise<ExtendedMessage[]> {
    const groupMessages = await db
      .select()
      .from(messages)
      .where(eq(messages.groupId, groupId))
      .orderBy(messages.timestamp);
    
    const extendedMessages: ExtendedMessage[] = [];
    
    for (const message of groupMessages) {
      const user = await this.getUser(message.userId);
      extendedMessages.push({
        ...message,
        username: user?.username || "Unknown User"
      });
    }
    
    return extendedMessages;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  // Resource methods
  async getUserAccessibleResources(userId: number): Promise<ExtendedResource[]> {
    // Get all groups the user is part of
    const userGroups = await db
      .select()
      .from(groupMembers)
      .where(eq(groupMembers.userId, userId));
    
    const groupIds = userGroups.map(membership => membership.groupId);
    
    // Get resources from those groups
    const userResources: ExtendedResource[] = [];
    
    for (const groupId of groupIds) {
      const groupResources = await db
        .select()
        .from(resources)
        .where(eq(resources.groupId, groupId))
        .orderBy(desc(resources.uploadedAt));
      
      for (const resource of groupResources) {
        const [group] = await db
          .select()
          .from(studyGroups)
          .where(eq(studyGroups.id, resource.groupId));
        
        const uploader = await this.getUser(resource.uploadedBy);
        
        userResources.push({
          ...resource,
          groupName: group?.name || "Unknown Group",
          uploadedByUsername: uploader?.username || "Unknown User"
        });
      }
    }
    
    return userResources;
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const [newResource] = await db.insert(resources).values(resource).returning();
    return newResource;
  }

  // Session methods
  async getUpcomingSessions(userId: number): Promise<ExtendedSession[]> {
    // Get all groups the user is part of
    const userGroups = await db
      .select()
      .from(groupMembers)
      .where(eq(groupMembers.userId, userId));
    
    const groupIds = userGroups.map(membership => membership.groupId);
    
    // Get upcoming sessions from those groups
    const now = new Date();
    const upcomingSessions: ExtendedSession[] = [];
    
    for (const groupId of groupIds) {
      const groupSessions = await db
        .select()
        .from(sessions)
        .where(
          and(
            eq(sessions.groupId, groupId),
            gte(sessions.date, now)
          )
        )
        .orderBy(sessions.date);
      
      for (const session of groupSessions) {
        const [group] = await db
          .select()
          .from(studyGroups)
          .where(eq(studyGroups.id, session.groupId));
        
        const host = await this.getUser(session.hostId);
        
        const participants = await db
          .select()
          .from(sessionParticipants)
          .where(eq(sessionParticipants.sessionId, session.id));
        
        upcomingSessions.push({
          ...session,
          groupName: group?.name || "Unknown Group",
          hostName: host?.username || "Unknown Host",
          participantCount: participants.length
        });
      }
    }
    
    return upcomingSessions;
  }

  async getSession(id: number): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session;
  }

  async createSession(session: InsertSession): Promise<Session> {
    const [newSession] = await db.insert(sessions).values(session).returning();
    return newSession;
  }

  async isSessionParticipant(sessionId: number, userId: number): Promise<boolean> {
    const count = await db
      .select()
      .from(sessionParticipants)
      .where(
        and(
          eq(sessionParticipants.sessionId, sessionId),
          eq(sessionParticipants.userId, userId)
        )
      );
    
    return count.length > 0;
  }

  async addSessionParticipant(participant: InsertSessionParticipant): Promise<SessionParticipant> {
    const [newParticipant] = await db
      .insert(sessionParticipants)
      .values(participant)
      .returning();
    
    return newParticipant;
  }

  // Notification methods
  async getUserNotifications(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async getNotification(id: number): Promise<Notification | undefined> {
    const [notification] = await db
      .select()
      .from(notifications)
      .where(eq(notifications.id, id));
    
    return notification;
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();
    
    return newNotification;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ unread: false })
      .where(eq(notifications.id, id));
  }

  // Activity methods
  async getUserRelevantActivities(userId: number): Promise<Activity[]> {
    // Get all activities by this user
    const userActivities = await db
      .select()
      .from(activities)
      .where(eq(activities.userId, userId));
    
    // Get all groups the user is part of
    const userGroups = await db
      .select()
      .from(groupMembers)
      .where(eq(groupMembers.userId, userId));
    
    const groupIds = userGroups.map(membership => membership.groupId);
    
    // Get all activities related to the user's groups
    const groupActivities: Activity[] = [];
    
    for (const groupId of groupIds) {
      const groupActs = await db
        .select()
        .from(activities)
        .where(
          and(
            eq(activities.relatedType, 'study_group'),
            eq(activities.relatedId, groupId)
          )
        );
      
      groupActivities.push(...groupActs);
    }
    
    // Combine and sort by timestamp
    const allActivities = [...userActivities, ...groupActivities]
      .filter((activity, index, self) =>
        index === self.findIndex(a => a.id === activity.id)
      )
      .sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    
    return allActivities;
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db
      .insert(activities)
      .values(activity)
      .returning();
    
    return newActivity;
  }

  // Helper methods
  private formatSessionDateTime(date: Date): string {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const sessionDate = new Date(date);
    const timeString = sessionDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    if (sessionDate.toDateString() === today.toDateString()) {
      return `Today, ${timeString}`;
    } else if (sessionDate.toDateString() === tomorrow.toDateString()) {
      return `Tomorrow, ${timeString}`;
    } else {
      return `${sessionDate.toLocaleDateString([], { weekday: 'long' })}, ${timeString}`;
    }
  }
}

// Use DatabaseStorage instead of MemStorage for production
export const storage = new DatabaseStorage();
