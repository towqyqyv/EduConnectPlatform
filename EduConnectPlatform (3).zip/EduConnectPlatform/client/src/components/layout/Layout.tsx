import React, { useState } from 'react';
import { useLocation } from 'wouter';
import Sidebar from './Sidebar';
import MobileNavigation from './MobileNavigation';
import { Menu, Bell, ChevronDown, User } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { ProfileSettings } from '@/components/profile/ProfileSettings';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  title = 'Dashboard' 
}) => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);

  const pageTitle = title || location.slice(1).charAt(0).toUpperCase() + location.slice(2);

  const toggleMobileSidebar = () => {
    setMobileSidebarOpen(!mobileSidebarOpen);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="flex flex-col h-screen">
      <div className="flex h-full overflow-hidden">
        {/* Desktop Sidebar */}
        <Sidebar />

        {/* Mobile Sidebar (hidden by default) */}
        {mobileSidebarOpen && (
          <div className="fixed inset-0 z-40 md:hidden">
            <div 
              className="absolute inset-0 bg-neutral-900 opacity-50"
              onClick={() => setMobileSidebarOpen(false)}
            ></div>
            <div className="absolute inset-y-0 left-0 w-64 bg-white shadow-lg">
              <Sidebar isMobile onClose={() => setMobileSidebarOpen(false)} />
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Top Navigation Bar */}
          <header className="bg-white border-b border-neutral-200 py-2 px-4 z-10">
            <div className="flex items-center justify-between">
              {/* Mobile Menu Button */}
              <button 
                className="md:hidden p-2 rounded-md text-neutral-700 hover:bg-neutral-100" 
                onClick={toggleMobileSidebar}
              >
                <Menu className="h-5 w-5" />
              </button>

              {/* Mobile Logo - Only visible on mobile */}
              <div className="flex md:hidden items-center">
                <div className="bg-primary rounded-lg w-8 h-8 flex items-center justify-center">
                  <span className="material-icons text-white text-sm">school</span>
                </div>
                <h1 className="font-heading font-semibold text-lg text-primary ml-2">EduConnect</h1>
              </div>

              {/* Page Title - Only visible on desktop */}
              <h2 className="text-lg font-heading font-medium hidden md:block">{pageTitle}</h2>

              {/* Right Actions */}
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <button className="p-2 rounded-md text-neutral-700 hover:bg-neutral-100 relative">
                    <Bell className="h-5 w-5" />
                    <span className="absolute top-1 right-1 bg-primary w-2 h-2 rounded-full"></span>
                  </button>
                </div>

                {/* Profile Menu (Desktop Only) */}
                <div className="hidden md:block relative">
                  <DropdownMenu>
                    <DropdownMenuTrigger className="flex items-center space-x-1 text-sm font-medium text-neutral-700 hover:text-primary focus:outline-none">
                      <User className="h-5 w-5 mr-1" />
                      <span>Profile</span>
                      <ChevronDown className="h-4 w-4" />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => setProfileOpen(true)} className="cursor-pointer">
                        Profile Settings
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        className="cursor-pointer text-red-500" 
                        onClick={handleLogout}
                      >
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
          </header>

          {/* Page Content */}
          <div className="flex-1 overflow-y-auto px-4 py-6 bg-neutral-100">
            {children}
          </div>
        </main>
      </div>
      <ProfileSettings open={profileOpen} onOpenChange={setProfileOpen} />
    </div>
  );
};

export default Layout;