import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Loader2, Send, MessagesSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function DiscussionsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Fetch user's joined study groups
  const { data: joinedGroups, isLoading: loadingGroups } = useQuery({
    queryKey: ['/api/study-groups/joined'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch joined groups');
      return res.json();
    },
  });
  
  // Fetch messages for selected group
  const { data: messages, isLoading: loadingMessages, refetch: refetchMessages } = useQuery({
    queryKey: ['/api/discussions', selectedGroupId],
    queryFn: async ({ queryKey }) => {
      if (!selectedGroupId) return [];
      const res = await fetch(`${queryKey[0]}/${queryKey[1]}`, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch messages');
      return res.json();
    },
    enabled: !!selectedGroupId,
  });
  
  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ groupId, content }: { groupId: string, content: string }) => {
      const res = await apiRequest('POST', `/api/discussions/${groupId}`, { content });
      return res.json();
    },
    onSuccess: () => {
      // Don't need to refetch as we'll get the message via WebSocket
      setMessage('');
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to send message',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Setup WebSocket connection
  useEffect(() => {
    if (!selectedGroupId) return;
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const newSocket = new WebSocket(wsUrl);
    
    newSocket.onopen = () => {
      console.log('WebSocket Connected');
      // Join chat room for selected group
      newSocket.send(JSON.stringify({
        type: 'join',
        groupId: selectedGroupId
      }));
    };
    
    newSocket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'message' && data.groupId === selectedGroupId) {
        // Update messages - using the refetch function from react-query
        refetchMessages();
      }
    };
    
    newSocket.onerror = (error) => {
      console.error('WebSocket Error:', error);
      toast({
        title: 'Connection error',
        description: 'Failed to connect to chat server',
        variant: 'destructive',
      });
    };
    
    setSocket(newSocket);
    
    return () => {
      // Leave current room before closing
      if (newSocket.readyState === WebSocket.OPEN) {
        newSocket.send(JSON.stringify({
          type: 'leave',
          groupId: selectedGroupId
        }));
        newSocket.close();
      }
    };
  }, [selectedGroupId]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle sending a message
  const handleSendMessage = () => {
    if (!message.trim() || !selectedGroupId) return;
    
    // Only send via WebSocket which will handle saving to database and broadcasting
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'message',
        groupId: selectedGroupId,
        content: message,
        userId: user?.id,
        username: user?.username
      }));
      setMessage(''); // Clear message input after sending
    } else {
      // Fallback to HTTP if WebSocket isn't available
      sendMessageMutation.mutate({
        groupId: selectedGroupId,
        content: message
      });
    }
  };

  // Handle pressing Enter to send message
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Find the selected group object
  const selectedGroup = joinedGroups?.find(group => group.id === selectedGroupId);

  return (
    <Layout title="Discussions">
      <div className="max-w-6xl mx-auto h-[calc(100vh-8rem)]">
        <div className="flex flex-col h-full">
          <Card className="mb-4">
            <CardContent className="pt-6 pb-4">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-bold">Discussions</h2>
                  <CardDescription>
                    Chat with your study groups in real-time
                  </CardDescription>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
                  <Select 
                    value={selectedGroupId || ''} 
                    onValueChange={(value) => setSelectedGroupId(value || null)}
                    disabled={loadingGroups}
                  >
                    <SelectTrigger className="w-full md:w-[260px]">
                      <SelectValue placeholder="Select a study group" />
                    </SelectTrigger>
                    <SelectContent>
                      {loadingGroups ? (
                        <div className="flex justify-center p-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </div>
                      ) : joinedGroups?.length > 0 ? (
                        joinedGroups.map((group) => (
                          <SelectItem key={group.id} value={group.id}>
                            {group.name}
                          </SelectItem>
                        ))
                      ) : (
                        <div className="p-2 text-center text-sm text-muted-foreground">
                          No study groups joined
                        </div>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {!selectedGroupId ? (
            <div className="flex-grow flex items-center justify-center bg-white rounded-lg border">
              <div className="text-center p-8">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <MessagesSquare className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-medium">Select a group to start chatting</h3>
                <p className="text-muted-foreground mt-2 max-w-md">
                  Choose a study group from the dropdown above to view and participate in discussions
                </p>
              </div>
            </div>
          ) : (
            <Card className="flex-grow flex flex-col">
              <CardHeader className="border-b py-3 px-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Avatar size="sm" shape="circle" fallback={selectedGroup?.name[0]} className="mr-2" />
                    <div>
                      <CardTitle className="text-lg">{selectedGroup?.name}</CardTitle>
                      <CardDescription className="text-xs">
                        {selectedGroup?.memberCount || 0} members
                      </CardDescription>
                    </div>
                  </div>
                  <Badge variant="outline">{selectedGroup?.subject}</Badge>
                </div>
              </CardHeader>
              
              <div className="flex-grow overflow-hidden">
                <ScrollArea className="h-full p-4">
                  {loadingMessages ? (
                    <div className="flex justify-center py-10">
                      <Loader2 className="h-10 w-10 animate-spin text-primary" />
                    </div>
                  ) : messages?.length > 0 ? (
                    <div className="space-y-4">
                      {messages.map((msg) => (
                        <div 
                          key={msg.id} 
                          className={`flex ${msg.userId === user?.id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div 
                            className={`max-w-[80%] ${
                              msg.userId === user?.id 
                                ? 'bg-primary text-primary-foreground' 
                                : 'bg-muted'
                            } rounded-lg px-4 py-2`}
                          >
                            {msg.userId !== user?.id && (
                              <div className="font-semibold text-xs mb-1">{msg.username}</div>
                            )}
                            <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            <div className="text-xs mt-1 opacity-70">{new Date(msg.timestamp).toLocaleTimeString()}</div>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center p-8">
                        <p className="text-muted-foreground">
                          No messages yet. Be the first to start the conversation!
                        </p>
                      </div>
                    </div>
                  )}
                </ScrollArea>
              </div>
              
              <CardFooter className="border-t p-4">
                <div className="flex w-full gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyDown={handleKeyPress}
                    disabled={sendMessageMutation.isPending}
                    className="flex-grow"
                  />
                  <Button 
                    onClick={handleSendMessage} 
                    disabled={!message.trim() || sendMessageMutation.isPending}
                  >
                    {sendMessageMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
