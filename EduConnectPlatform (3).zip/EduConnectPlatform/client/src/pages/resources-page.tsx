import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Loader2, Upload, Download, FileText, File, X, Search, Filter, Link2, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Resource type definition for type checking
interface Resource {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  groupId: string;
  groupName: string;
  uploadedBy: string;
  uploadedAt: string;
}

export default function ResourcesPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [resourceUrl, setResourceUrl] = useState('');
  const [resourceName, setResourceName] = useState('');
  const [uploadTab, setUploadTab] = useState('file');
  
  const isTeacher = user?.role === 'teacher';

  // Fetch all resources
  const { data: resources, isLoading: loadingResources } = useQuery({
    queryKey: ['/api/resources'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch resources');
      return res.json();
    },
  });
  
  // Fetch user's joined study groups
  const { data: joinedGroups, isLoading: loadingGroups } = useQuery({
    queryKey: ['/api/study-groups/joined'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch joined groups');
      return res.json();
    },
  });
  
  // Upload resource mutation
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch('/api/resources', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!res.ok) {
        const error = await res.text();
        throw new Error(error || 'Failed to upload resource');
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/resources'] });
      toast({
        title: 'Resource uploaded',
        description: 'Your resource has been uploaded successfully',
      });
      setIsUploadOpen(false);
      resetUploadForm();
    },
    onError: (error: Error) => {
      toast({
        title: 'Upload failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Create link resource mutation
  const createLinkMutation = useMutation({
    mutationFn: async (linkData: { name: string, url: string, groupId: string }) => {
      const res = await apiRequest('POST', '/api/resources/link', linkData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/resources'] });
      toast({
        title: 'Link added',
        description: 'Your link has been added to resources',
      });
      setIsUploadOpen(false);
      resetUploadForm();
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to add link',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Reset the upload form
  const resetUploadForm = () => {
    setUploadFile(null);
    setResourceUrl('');
    setResourceName('');
    setUploadTab('file');
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'File too large',
          description: 'Maximum file size is 5MB',
          variant: 'destructive',
        });
        e.target.value = '';
        return;
      }
      
      setUploadFile(file);
    }
  };

  // Handle resource upload
  const handleUpload = () => {
    if (uploadTab === 'file') {
      if (!uploadFile || !selectedGroupId || selectedGroupId === 'all') {
        toast({
          title: 'Missing information',
          description: 'Please select a file and a study group',
          variant: 'destructive',
        });
        return;
      }
      
      const formData = new FormData();
      formData.append('file', uploadFile);
      formData.append('groupId', selectedGroupId);
      
      uploadMutation.mutate(formData);
    } else {
      // Handle link resource
      if (!resourceUrl || !resourceName || !selectedGroupId || selectedGroupId === 'all') {
        toast({
          title: 'Missing information',
          description: 'Please fill in all fields',
          variant: 'destructive',
        });
        return;
      }
      
      // Validate URL
      try {
        new URL(resourceUrl);
      } catch (e) {
        toast({
          title: 'Invalid URL',
          description: 'Please enter a valid URL including http:// or https://',
          variant: 'destructive',
        });
        return;
      }
      
      createLinkMutation.mutate({
        name: resourceName,
        url: resourceUrl,
        groupId: selectedGroupId
      });
    }
  };

  // Filter resources based on search term, group and type
  const filteredResources = resources?.filter((resource: Resource) => {
    const matchesSearch = 
      resource.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      resource.groupName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.uploadedBy.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesGroup = selectedGroupId === 'all' || resource.groupId === selectedGroupId;
    const matchesType = selectedType === 'all' || resource.type === selectedType;
    
    return matchesSearch && matchesGroup && matchesType;
  });

  // Format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Get icon for resource type
  const getResourceIcon = (type: string) => {
    switch(type) {
      case 'pdf':
        return <FileText className="h-4 w-4" />;
      case 'doc':
      case 'docx':
        return <File className="h-4 w-4 text-blue-500" />;
      case 'xls':
      case 'xlsx':
        return <File className="h-4 w-4 text-green-500" />;
      case 'ppt':
      case 'pptx':
        return <File className="h-4 w-4 text-red-500" />;
      case 'link':
        return <Link2 className="h-4 w-4 text-purple-500" />;
      default:
        return <File className="h-4 w-4" />;
    }
  };

  // Get unique resource types for filtering
  const resourceTypes = resources 
    ? ['all', ...new Set(resources.map((resource: Resource) => resource.type))]
    : ['all'];

  const isLoading = loadingResources || loadingGroups;
  const isPending = uploadMutation.isPending || createLinkMutation.isPending;

  return (
    <Layout title="Resources">
      <div className="max-w-7xl mx-auto space-y-6 pb-20">
        {/* Header Section */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-2xl font-bold">Resource Library</h2>
                <CardDescription>
                  Access and share study materials with your groups
                </CardDescription>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
                <div className="relative flex-grow">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search resources..." 
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Upload className="h-4 w-4 mr-2" />
                      Add Resource
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Resource</DialogTitle>
                      <DialogDescription>
                        Share a file or link with your study group.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Tabs defaultValue="file" value={uploadTab} onValueChange={setUploadTab}>
                      <TabsList className="grid w-full grid-cols-2 mb-4">
                        <TabsTrigger value="file">Upload File</TabsTrigger>
                        <TabsTrigger value="link">Add Link</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="file">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="file-upload">Choose File (Max 5MB)</Label>
                            <div className="mt-1 flex items-center">
                              <Input
                                id="file-upload"
                                type="file"
                                onChange={handleFileChange}
                                className="flex-grow"
                              />
                              {uploadFile && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => setUploadFile(null)}
                                  className="ml-2"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                            {uploadFile && (
                              <div className="text-sm text-muted-foreground mt-1">
                                {uploadFile.name} ({formatFileSize(uploadFile.size)})
                              </div>
                            )}
                          </div>
                          
                          <div>
                            <Label htmlFor="study-group">Study Group</Label>
                            <Select 
                              value={selectedGroupId} 
                              onValueChange={setSelectedGroupId}
                            >
                              <SelectTrigger id="study-group" className="w-full mt-1">
                                <SelectValue placeholder="Select a study group" />
                              </SelectTrigger>
                              <SelectContent>
                                {loadingGroups ? (
                                  <div className="flex justify-center p-2">
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  </div>
                                ) : joinedGroups?.length > 0 ? (
                                  joinedGroups.map((group) => (
                                    <SelectItem key={group.id} value={group.id}>
                                      {group.name}
                                    </SelectItem>
                                  ))
                                ) : (
                                  <div className="p-2 text-center text-sm text-muted-foreground">
                                    No study groups joined
                                  </div>
                                )}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="link">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="link-name">Link Name</Label>
                            <Input
                              id="link-name"
                              value={resourceName}
                              onChange={(e) => setResourceName(e.target.value)}
                              placeholder="e.g. Helpful Article on Calculus"
                              className="mt-1"
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="link-url">URL</Label>
                            <Input
                              id="link-url"
                              type="url"
                              value={resourceUrl}
                              onChange={(e) => setResourceUrl(e.target.value)}
                              placeholder="https://example.com/resource"
                              className="mt-1"
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="study-group-link">Study Group</Label>
                            <Select 
                              value={selectedGroupId} 
                              onValueChange={setSelectedGroupId}
                            >
                              <SelectTrigger id="study-group-link" className="w-full mt-1">
                                <SelectValue placeholder="Select a study group" />
                              </SelectTrigger>
                              <SelectContent>
                                {loadingGroups ? (
                                  <div className="flex justify-center p-2">
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  </div>
                                ) : joinedGroups?.length > 0 ? (
                                  joinedGroups.map((group) => (
                                    <SelectItem key={group.id} value={group.id}>
                                      {group.name}
                                    </SelectItem>
                                  ))
                                ) : (
                                  <div className="p-2 text-center text-sm text-muted-foreground">
                                    No study groups joined
                                  </div>
                                )}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </TabsContent>
                    </Tabs>
                    
                    <DialogFooter>
                      <Button 
                        variant="outline" 
                        onClick={() => setIsUploadOpen(false)} 
                        disabled={isPending}
                      >
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleUpload}
                        disabled={isPending}
                      >
                        {isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            {uploadTab === 'file' ? 'Uploading...' : 'Adding...'}
                          </>
                        ) : (
                          <>
                            {uploadTab === 'file' ? 'Upload' : 'Add Link'}
                          </>
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Filter Controls */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="w-full sm:w-1/3 lg:w-1/4">
            <Label htmlFor="filter-group">Filter by Group</Label>
            <Select 
              value={selectedGroupId} 
              onValueChange={setSelectedGroupId}
            >
              <SelectTrigger id="filter-group" className="w-full mt-1">
                <SelectValue placeholder="All Groups" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Groups</SelectItem>
                {loadingGroups ? (
                  <div className="flex justify-center p-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                ) : joinedGroups?.length > 0 ? (
                  joinedGroups.map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.name}
                    </SelectItem>
                  ))
                ) : (
                  <div className="p-2 text-center text-sm text-muted-foreground">
                    No study groups joined
                  </div>
                )}
              </SelectContent>
            </Select>
          </div>
          
          <div className="w-full sm:w-1/3 lg:w-1/4">
            <Label htmlFor="filter-type">Filter by Type</Label>
            <Select 
              value={selectedType} 
              onValueChange={setSelectedType}
            >
              <SelectTrigger id="filter-type" className="w-full mt-1">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                {resourceTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type === 'all' ? 'All Types' : type.toUpperCase()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Resources Table */}
        <Card>
          <CardHeader>
            <CardTitle>Resources</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-10">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
              </div>
            ) : filteredResources?.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Group</TableHead>
                    <TableHead>Uploaded By</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredResources.map((resource: Resource) => (
                    <TableRow key={resource.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center">
                          {getResourceIcon(resource.type)}
                          <span className="ml-2">{resource.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {resource.type.toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {resource.type === 'link' ? '-' : formatFileSize(resource.size)}
                      </TableCell>
                      <TableCell>{resource.groupName}</TableCell>
                      <TableCell>{resource.uploadedBy}</TableCell>
                      <TableCell>
                        {new Date(resource.uploadedAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        {resource.type === 'link' ? (
                          <a
                            href={resource.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center"
                          >
                            <Button variant="ghost" size="sm">
                              <ExternalLink className="h-4 w-4 mr-1" />
                              Open
                            </Button>
                          </a>
                        ) : (
                          <a
                            href={resource.url}
                            download
                            className="inline-flex items-center"
                          >
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4 mr-1" />
                              Download
                            </Button>
                          </a>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-20 border rounded-lg bg-white">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <Filter className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-medium">No resources found</h3>
                <p className="text-muted-foreground mt-1 mb-6">
                  {searchTerm 
                    ? 'No resources match your search criteria.'
                    : 'There are no resources available in your study groups yet.'}
                </p>
                <Button onClick={() => setIsUploadOpen(true)}>
                  <Upload className="h-4 w-4 mr-2" />
                  Add Your First Resource
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
