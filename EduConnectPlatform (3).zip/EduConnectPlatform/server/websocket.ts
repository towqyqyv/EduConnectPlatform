import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from './storage';

interface WebSocketClient extends WebSocket {
  userId?: number;
  groupIds?: number[];
  isAlive?: boolean;
}

interface ChatMessage {
  type: string;
  groupId: number;
  content?: string;
  userId?: number;
  username?: string;
}

export function setupWebSockets(server: Server): void {
  const wss = new WebSocketServer({ server, path: '/ws' });

  // Store group chat rooms
  const chatRooms: Map<number, Set<WebSocketClient>> = new Map();

  // Ping-pong to detect disconnected clients
  const interval = setInterval(() => {
    wss.clients.forEach((ws: WebSocketClient) => {
      if (ws.isAlive === false) return ws.terminate();
      
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => {
    clearInterval(interval);
  });

  wss.on('connection', (ws: WebSocketClient) => {
    console.log('WebSocket client connected');
    ws.isAlive = true;
    ws.groupIds = [];

    // Handle pong response
    ws.on('pong', () => {
      ws.isAlive = true;
    });

    // Handle messages
    ws.on('message', async (message: string) => {
      try {
        const data: ChatMessage = JSON.parse(message);
        
        switch (data.type) {
          case 'join':
            // Join a chat room
            if (data.groupId) {
              // Add client to the chat room
              if (!chatRooms.has(data.groupId)) {
                chatRooms.set(data.groupId, new Set());
              }
              chatRooms.get(data.groupId)?.add(ws);
              
              // Keep track of joined groups for this client
              if (!ws.groupIds?.includes(data.groupId)) {
                ws.groupIds?.push(data.groupId);
              }
              
              console.log(`Client joined chat room for group ${data.groupId}`);
            }
            break;
            
          case 'leave':
            // Leave a chat room
            if (data.groupId && ws.groupIds?.includes(data.groupId)) {
              chatRooms.get(data.groupId)?.delete(ws);
              ws.groupIds = ws.groupIds.filter(id => id !== data.groupId);
              console.log(`Client left chat room for group ${data.groupId}`);
            }
            break;
            
          case 'message':
            // Send message to a chat room
            if (data.groupId && data.content && data.userId && data.username) {
              // Save message to database
              await storage.createMessage({
                content: data.content,
                userId: data.userId,
                groupId: data.groupId
              });
              
              // Broadcast to all clients in the room
              const clients = chatRooms.get(data.groupId);
              if (clients) {
                const messageData = JSON.stringify({
                  type: 'message',
                  groupId: data.groupId,
                  content: data.content,
                  userId: data.userId,
                  username: data.username,
                  timestamp: new Date().toISOString()
                });
                
                clients.forEach(client => {
                  if (client.readyState === WebSocket.OPEN) {
                    client.send(messageData);
                  }
                });
                
                console.log(`Message broadcast to ${clients.size} clients in group ${data.groupId}`);
              }
            }
            break;
            
          default:
            console.log(`Unknown message type: ${data.type}`);
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });

    // Handle disconnection
    ws.on('close', () => {
      console.log('WebSocket client disconnected');
      
      // Remove client from all chat rooms
      if (ws.groupIds && ws.groupIds.length > 0) {
        ws.groupIds.forEach(groupId => {
          chatRooms.get(groupId)?.delete(ws);
        });
      }
    });
  });

  console.log('WebSocket server initialized on path: /ws');
}
