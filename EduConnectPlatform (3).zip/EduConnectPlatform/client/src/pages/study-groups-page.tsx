import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Loader2, Plus, Search, Filter, UserPlus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';

const createGroupSchema = z.object({
  name: z.string().min(3, "Group name must be at least 3 characters").max(50, "Group name must be less than 50 characters"),
  description: z.string().min(10, "Description must be at least 10 characters").max(500, "Description must be less than 500 characters"),
  subject: z.string().min(2, "Subject is required"),
  isPrivate: z.boolean().default(false),
});

type CreateGroupForm = z.infer<typeof createGroupSchema>;

export default function StudyGroupsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [openCreateDialog, setOpenCreateDialog] = useState(false);
  const [activeTab, setActiveTab] = useState('all');

  const isTeacher = user?.role === 'teacher';

  // Fetch all study groups
  const { data: studyGroups, isLoading: loadingGroups } = useQuery({
    queryKey: ['/api/study-groups'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch study groups');
      return res.json();
    },
  });

  // Fetch user's joined study groups
  const { data: joinedGroups, isLoading: loadingJoined } = useQuery({
    queryKey: ['/api/study-groups/joined'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch joined groups');
      return res.json();
    },
  });

  // Fetch created study groups (if teacher)
  const { data: createdGroups, isLoading: loadingCreated } = useQuery({
    queryKey: ['/api/study-groups/created'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch created groups');
      return res.json();
    },
    enabled: isTeacher,
  });

  // Create study group mutation
  const createGroupMutation = useMutation({
    mutationFn: async (groupData: CreateGroupForm) => {
      const res = await apiRequest('POST', '/api/study-groups', groupData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/study-groups'] });
      queryClient.invalidateQueries({ queryKey: ['/api/study-groups/created'] });
      toast({
        title: 'Study group created',
        description: 'Your new study group has been created successfully',
      });
      setOpenCreateDialog(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to create group',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Join study group mutation
  const joinGroupMutation = useMutation({
    mutationFn: async (groupId: string) => {
      const res = await apiRequest('POST', `/api/study-groups/${groupId}/join`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/study-groups'] });
      queryClient.invalidateQueries({ queryKey: ['/api/study-groups/joined'] });
      toast({
        title: 'Group joined',
        description: 'You have successfully joined the study group',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to join group',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Form for creating a study group
  const form = useForm<CreateGroupForm>({
    resolver: zodResolver(createGroupSchema),
    defaultValues: {
      name: '',
      description: '',
      subject: '',
      isPrivate: false,
    },
  });

  const onSubmit = (data: CreateGroupForm) => {
    createGroupMutation.mutate(data);
  };

  // Filter groups by search term
  const filterGroups = (groups) => {
    if (!groups) return [];

    return groups.filter(group => 
      group.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      group.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      group.subject.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  // Get the active groups to display based on selected tab
  const getActiveGroups = () => {
    switch (activeTab) {
      case 'joined':
        return filterGroups(joinedGroups);
      case 'created':
        return filterGroups(createdGroups);
      default:
        return filterGroups(studyGroups);
    }
  };

  // Handle joining a group
  const handleJoinGroup = (groupId: string) => {
    joinGroupMutation.mutate(groupId);
  };

  // Check if user has already joined a group
  const hasJoinedGroup = (groupId: string) => {
    return joinedGroups?.some(group => group.id === groupId);
  };

  const activeGroups = getActiveGroups();
  const isLoading = loadingGroups || loadingJoined || (isTeacher && loadingCreated);

  return (
    <Layout title="Study Groups">
      <div className="max-w-7xl mx-auto space-y-6 pb-20">
        {/* Header Section */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-2xl font-bold">Study Groups</h2>
                <CardDescription>
                  Join existing groups or create your own to collaborate with peers
                </CardDescription>
              </div>

              <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
                <div className="relative flex-grow">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search groups..." 
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>

                {isTeacher && (
                  <Dialog open={openCreateDialog} onOpenChange={setOpenCreateDialog}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Create Group
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create New Study Group</DialogTitle>
                        <DialogDescription>
                          Fill in the details to create a new study group. Required fields are marked with an asterisk.
                        </DialogDescription>
                      </DialogHeader>
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                          <FormField
                            control={form.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Group Name *</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g. Advanced Mathematics" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="subject"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Subject *</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g. Math, History, Science" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description *</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Describe what the group will focus on..." 
                                    className="resize-none" 
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="isPrivate"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                <FormControl>
                                  <input
                                    type="checkbox"
                                    checked={field.value}
                                    onChange={field.onChange}
                                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                  />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                  <FormLabel>Private Group</FormLabel>
                                  <FormDescription>
                                    Private groups require approval to join
                                  </FormDescription>
                                </div>
                              </FormItem>
                            )}
                          />

                          <DialogFooter>
                            <Button 
                              type="submit" 
                              disabled={createGroupMutation.isPending}
                            >
                              {createGroupMutation.isPending ? (
                                <>
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                  Creating...
                                </>
                              ) : (
                                "Create Group"
                              )}
                            </Button>
                          </DialogFooter>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Groups Tabs and Listing */}
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">All Groups</TabsTrigger>
            <TabsTrigger value="joined">Joined Groups</TabsTrigger>
            {isTeacher && (
              <TabsTrigger value="created">Created Groups</TabsTrigger>
            )}
          </TabsList>

          <TabsContent value={activeTab} className="mt-6">
            {isLoading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
              </div>
            ) : activeGroups?.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeGroups.map((group) => (
                  <Card key={group.id} className="overflow-hidden h-full flex flex-col">
                    <div className="h-40 relative bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                      <span className="material-icons text-6xl text-primary/80">
                        {group.subject?.toLowerCase().includes('math') ? 'functions' :
                         group.subject?.toLowerCase().includes('science') ? 'science' :
                         group.subject?.toLowerCase().includes('history') ? 'history_edu' :
                         group.subject?.toLowerCase().includes('language') ? 'translate' :
                         group.subject?.toLowerCase().includes('computer') ? 'computer' :
                         group.subject?.toLowerCase().includes('art') ? 'palette' :
                         group.subject?.toLowerCase().includes('music') ? 'music_note' :
                         'school'}
                      </span>
                      {group.isPrivate && (
                        <Badge 
                          variant="secondary" 
                          className="absolute top-2 left-2 bg-black/70 text-white"
                        >
                          Private
                        </Badge>
                      )}
                      <div className="absolute bottom-2 right-2 bg-white/90 text-xs px-2 py-1 rounded-full">
                        <span className="text-primary font-medium">{group.memberCount || 0} members</span>
                      </div>
                    </div>

                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{group.name}</CardTitle>
                          <Badge variant="outline" className="mt-1">
                            {group.subject}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="flex-grow">
                      <p className="text-sm text-muted-foreground">
                        {group.description}
                      </p>

                      <div className="mt-4 flex items-center text-sm text-muted-foreground">
                        <span className="material-icons text-xs mr-1">person</span>
                        <span>Created by: {group.createdBy}</span>
                      </div>
                    </CardContent>

                    <CardFooter className="border-t pt-4">
                      {!hasJoinedGroup(group.id) ? (
                        <Button 
                          onClick={() => handleJoinGroup(group.id)} 
                          disabled={joinGroupMutation.isPending}
                          className="w-full"
                        >
                          {joinGroupMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <UserPlus className="h-4 w-4 mr-2" />
                          )}
                          Join Group
                        </Button>
                      ) : (
                        <Button 
                          variant="secondary" 
                          className="w-full"
                          onClick={() => window.location.href = `/groups/${group.id}`}
                        >
                          View Group
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-20 border rounded-lg bg-white">
                <div className="flex justify-center mb-4">
                  <div className="p-3 rounded-full bg-primary/10">
                    <Filter className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-lg font-medium">No study groups found</h3>
                <p className="text-muted-foreground mt-1 mb-6">
                  {activeTab === 'all' 
                    ? 'There are no study groups available matching your search.' 
                    : activeTab === 'joined'
                      ? 'You haven\'t joined any study groups yet.'
                      : 'You haven\'t created any study groups yet.'}
                </p>
                {isTeacher && activeTab === 'created' && (
                  <Button onClick={() => setOpenCreateDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Your First Group
                  </Button>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}