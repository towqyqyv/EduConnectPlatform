import React from 'react';
import { Link, useLocation } from 'wouter';

const MobileNavigation: React.FC = () => {
  const [location] = useLocation();

  const navItems = [
    { path: '/dashboard', icon: 'dashboard', label: 'Dashboard' },
    { path: '/study-groups', icon: 'groups', label: 'Groups' },
    { path: '/discussions', icon: 'forum', label: 'Discuss' },
    { path: '/resources', icon: 'library_books', label: 'Resources' },
    { path: '/more', icon: 'more_horiz', label: 'More', dropdown: true }
  ];

  return (
    <nav className="md:hidden bg-white border-t border-neutral-200 fixed bottom-0 left-0 right-0 z-30">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a className={`flex flex-col items-center py-2 px-3 ${
              location === item.path ? 'text-primary' : 'text-neutral-500'
            }`}>
              <span className="material-icons">{item.icon}</span>
              <span className="text-xs mt-1">{item.label}</span>
            </a>
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default MobileNavigation;
