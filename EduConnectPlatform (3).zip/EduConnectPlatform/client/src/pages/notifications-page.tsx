import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import Layout from '@/components/layout/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Loader2, Bell, BellOff, CheckCircle, Filter } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Notification {
  id: number;
  title: string;
  message: string;
  type: string;
  icon: string;
  relatedId?: number;
  relatedType?: string;
  unread: boolean;
  createdAt: string;
}

export default function NotificationsPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('all');
  
  // Fetch notifications
  const { data: notifications, isLoading } = useQuery({
    queryKey: ['/api/notifications'],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, { credentials: 'include' });
      if (!res.ok) throw new Error('Failed to fetch notifications');
      return res.json();
    },
  });
  
  // Mark notification as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const res = await apiRequest('POST', `/api/notifications/${notificationId}/read`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to mark notification as read',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Mark all as read mutation
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      // In a real implementation, this would be a dedicated API endpoint
      // For now, we'll mark individual notifications
      const unreadNotifications = notifications.filter(n => n.unread);
      const promises = unreadNotifications.map(notification => 
        apiRequest('POST', `/api/notifications/${notification.id}/read`)
      );
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
      toast({
        title: 'All notifications marked as read',
        description: 'Your notifications have been updated',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to mark all as read',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Handle marking a notification as read
  const handleMarkAsRead = (notificationId: number) => {
    markAsReadMutation.mutate(notificationId);
  };

  // Handle marking all notifications as read
  const handleMarkAllAsRead = () => {
    markAllAsReadMutation.mutate();
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    
    return date.toLocaleDateString();
  };

  // Filter notifications based on tab
  const filteredNotifications = notifications?.filter((notification: Notification) => {
    if (activeTab === 'unread') return notification.unread;
    if (activeTab === 'study-groups') return notification.relatedType === 'study_group';
    if (activeTab === 'discussions') return notification.relatedType === 'discussion';
    if (activeTab === 'sessions') return notification.relatedType === 'session';
    return true; // 'all' tab
  });

  // Get notification icon based on type and icon field
  const getNotificationIcon = (notification: Notification) => {
    const iconClassName = "material-icons text-sm";
    const type = notification.type || 'info';
    const icon = notification.icon || (
      type === 'info' ? 'info' : 
      type === 'success' ? 'check_circle' : 
      type === 'warning' ? 'warning' : 
      type === 'error' ? 'error' : 'notifications'
    );
    
    return <span className={iconClassName}>{icon}</span>;
  };

  // Get notification color based on type
  const getNotificationColor = (type: string) => {
    switch(type) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'error': return 'bg-red-100 text-red-800';
      case 'info': 
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  // Count unread notifications
  const unreadCount = notifications?.filter((n: Notification) => n.unread).length || 0;

  return (
    <Layout title="Notifications">
      <div className="max-w-5xl mx-auto space-y-6 pb-20">
        {/* Header Section */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h2 className="text-2xl font-bold">Notifications</h2>
                <CardDescription>
                  Stay updated with activity from your study groups and sessions
                </CardDescription>
              </div>
              
              <div>
                <Button 
                  variant="outline" 
                  onClick={handleMarkAllAsRead}
                  disabled={markAllAsReadMutation.isPending || unreadCount === 0}
                >
                  {markAllAsReadMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <CheckCircle className="h-4 w-4 mr-2" />
                  )}
                  Mark All as Read
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Notification Filters and List */}
        <div className="flex flex-col space-y-4">
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">
                All
                {notifications?.length > 0 && (
                  <Badge variant="secondary" className="ml-2">{notifications.length}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="unread">
                Unread
                {unreadCount > 0 && (
                  <Badge variant="secondary" className="ml-2">{unreadCount}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="study-groups">Study Groups</TabsTrigger>
              <TabsTrigger value="discussions">Discussions</TabsTrigger>
              <TabsTrigger value="sessions">Sessions</TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab} className="mt-6">
              {isLoading ? (
                <div className="flex justify-center py-10">
                  <Loader2 className="h-10 w-10 animate-spin text-primary" />
                </div>
              ) : filteredNotifications?.length > 0 ? (
                <div className="space-y-4">
                  {filteredNotifications.map((notification: Notification) => (
                    <Card key={notification.id} className={notification.unread ? 'border-l-4 border-l-primary' : ''}>
                      <CardContent className="flex items-start p-4">
                        <div className={`rounded-full p-2 mr-4 ${getNotificationColor(notification.type)}`}>
                          {getNotificationIcon(notification)}
                        </div>
                        
                        <div className="flex-grow">
                          <div className="flex justify-between items-start">
                            <h3 className="font-medium">{notification.title}</h3>
                            <div className="flex items-center">
                              <span className="text-xs text-muted-foreground mr-3">
                                {formatDate(notification.createdAt)}
                              </span>
                              {notification.unread && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleMarkAsRead(notification.id)}
                                  disabled={markAsReadMutation.isPending}
                                  className="h-8 w-8 p-0"
                                >
                                  {markAsReadMutation.isPending ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <BellOff className="h-4 w-4" />
                                  )}
                                </Button>
                              )}
                            </div>
                          </div>
                          
                          <p className="text-sm text-muted-foreground mt-1">
                            {notification.message}
                          </p>
                          
                          {notification.relatedType && (
                            <div className="mt-2">
                              <Badge variant="outline" className="text-xs">
                                {notification.relatedType.replace('-', ' ')}
                              </Badge>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-20 border rounded-lg bg-white">
                  <div className="flex justify-center mb-4">
                    <div className="p-3 rounded-full bg-primary/10">
                      <Bell className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-lg font-medium">No notifications found</h3>
                  <p className="text-muted-foreground mt-1 mb-6">
                    {activeTab === 'unread' 
                      ? 'You have no unread notifications.'
                      : activeTab === 'all'
                        ? 'You have no notifications yet.'
                        : `You have no notifications related to ${activeTab.replace('-', ' ')}.`}
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
}
