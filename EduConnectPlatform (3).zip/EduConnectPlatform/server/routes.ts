import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { setupWebSockets } from "./websocket";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertStudyGroupSchema, insertMessageSchema, insertResourceSchema, insertSessionSchema } from "@shared/schema";

// Create uploads directory if it doesn't exist
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const ext = path.extname(file.originalname);
      cb(null, uniqueSuffix + ext);
    }
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);

  // Create HTTP server
  const httpServer = createServer(app);
  
  // Set up WebSockets for real-time chat
  setupWebSockets(httpServer);

  // Study Groups API
  app.get("/api/study-groups", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const groups = await storage.getAllStudyGroups();
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch study groups" });
    }
  });

  app.get("/api/study-groups/joined", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const groups = await storage.getJoinedStudyGroups(req.user.id);
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch joined study groups" });
    }
  });

  app.get("/api/study-groups/created", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      if (req.user.role !== "teacher") {
        return res.status(403).json({ message: "Only teachers can access created groups" });
      }
      
      const groups = await storage.getCreatedStudyGroups(req.user.id);
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch created study groups" });
    }
  });

  app.post("/api/study-groups", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      if (req.user.role !== "teacher") {
        return res.status(403).json({ message: "Only teachers can create study groups" });
      }
      
      const validatedData = insertStudyGroupSchema.parse({
        ...req.body,
        createdBy: req.user.id
      });
      
      // Check if group name already exists
      const existingGroup = await storage.getStudyGroupByName(validatedData.name);
      if (existingGroup) {
        return res.status(400).json({ message: "A study group with this name already exists" });
      }
      
      const group = await storage.createStudyGroup(validatedData);
      
      // Automatically add the creator to the group
      await storage.addMemberToGroup(req.user.id, group.id);
      
      // Create activity record
      await storage.createActivity({
        userId: req.user.id,
        description: `Created a new study group: <span class="font-medium">${group.name}</span>`,
        icon: "groups",
        iconColor: "primary",
        relatedId: group.id,
        relatedType: "study_group"
      });
      
      res.status(201).json(group);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create study group" });
    }
  });

  app.post("/api/study-groups/:id/join", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const groupId = parseInt(req.params.id);
      if (isNaN(groupId)) {
        return res.status(400).json({ message: "Invalid group ID" });
      }
      
      // Check if group exists
      const group = await storage.getStudyGroup(groupId);
      if (!group) {
        return res.status(404).json({ message: "Study group not found" });
      }
      
      // Check if user is already a member
      const isMember = await storage.isGroupMember(req.user.id, groupId);
      if (isMember) {
        return res.status(400).json({ message: "You are already a member of this group" });
      }
      
      // Add user to group
      await storage.addMemberToGroup(req.user.id, groupId);
      
      // Create activity record
      await storage.createActivity({
        userId: req.user.id,
        description: `Joined the study group: <span class="font-medium">${group.name}</span>`,
        icon: "group_add",
        iconColor: "accent",
        relatedId: groupId,
        relatedType: "study_group"
      });
      
      // Create notification for group creator
      await storage.createNotification({
        userId: group.createdBy,
        title: "New group member",
        message: `${req.user.username} joined your ${group.name} group`,
        type: "info",
        icon: "person_add",
        relatedId: groupId,
        relatedType: "study_group",
        unread: true
      });
      
      res.status(200).json({ message: "Successfully joined group" });
    } catch (error) {
      res.status(500).json({ message: "Failed to join study group" });
    }
  });

  // Discussions API
  app.get("/api/discussions/:groupId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const groupId = parseInt(req.params.groupId);
      if (isNaN(groupId)) {
        return res.status(400).json({ message: "Invalid group ID" });
      }
      
      // Check if user is a member of the group
      const isMember = await storage.isGroupMember(req.user.id, groupId);
      if (!isMember) {
        return res.status(403).json({ message: "You must be a member of this group to view discussions" });
      }
      
      const messages = await storage.getGroupMessages(groupId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/discussions/:groupId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const groupId = parseInt(req.params.groupId);
      if (isNaN(groupId)) {
        return res.status(400).json({ message: "Invalid group ID" });
      }
      
      // Check if user is a member of the group
      const isMember = await storage.isGroupMember(req.user.id, groupId);
      if (!isMember) {
        return res.status(403).json({ message: "You must be a member of this group to post messages" });
      }
      
      const validatedData = insertMessageSchema.parse({
        content: req.body.content,
        userId: req.user.id,
        groupId
      });
      
      // Filter inappropriate content (simple example)
      const inappropriateWords = ["inappropriate", "offensive", "explicit"];
      const hasInappropriateContent = inappropriateWords.some(word => 
        validatedData.content.toLowerCase().includes(word)
      );
      
      if (hasInappropriateContent) {
        return res.status(400).json({ message: "Message contains inappropriate content" });
      }
      
      const message = await storage.createMessage(validatedData);
      
      // Get group name for notifications
      const group = await storage.getStudyGroup(groupId);
      
      // Create notifications for other group members
      const groupMembers = await storage.getGroupMembers(groupId);
      for (const member of groupMembers) {
        if (member.userId !== req.user.id) {
          await storage.createNotification({
            userId: member.userId,
            title: "New message in group chat",
            message: `${req.user.username}: ${validatedData.content.substring(0, 30)}${validatedData.content.length > 30 ? '...' : ''}`,
            type: "info",
            icon: "chat",
            relatedId: groupId,
            relatedType: "discussion",
            unread: true
          });
        }
      }
      
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // Resources API
  app.get("/api/resources", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const resources = await storage.getUserAccessibleResources(req.user.id);
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resources" });
    }
  });

  // Add link resource
  app.post("/api/resources/link", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const { name, url, groupId } = req.body;
      
      if (!name || !url || !groupId) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Check if user is a member of the group
      const isMember = await storage.isGroupMember(req.user.id, parseInt(groupId));
      if (!isMember) {
        return res.status(403).json({ message: "You must be a member of this group to add resources" });
      }
      
      // Validate URL format
      try {
        new URL(url);
      } catch (e) {
        return res.status(400).json({ message: "Invalid URL format" });
      }
      
      const resource = await storage.createResource({
        name,
        type: "link",
        size: 0,
        url,
        uploadedBy: req.user.id,
        groupId: parseInt(groupId)
      });
      
      // Create activity record
      const group = await storage.getStudyGroup(parseInt(groupId));
      await storage.createActivity({
        userId: req.user.id,
        description: `Added a link: <span class="font-medium">${name}</span> to ${group.name} group`,
        icon: "link",
        iconColor: "info",
        relatedId: resource.id,
        relatedType: "resource"
      });
      
      res.status(201).json(resource);
    } catch (error) {
      res.status(500).json({ message: "Failed to add link" });
    }
  });

  // File upload endpoint with multer
  app.post("/api/resources", upload.single('file'), async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Check if file was uploaded
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Get groupId from the form data
      const groupId = req.body.groupId;
      if (!groupId) {
        return res.status(400).json({ message: "Missing group ID" });
      }
      
      // Check if user is a member of the group
      const isMember = await storage.isGroupMember(req.user.id, parseInt(groupId));
      if (!isMember) {
        return res.status(403).json({ message: "You must be a member of this group to add resources" });
      }
      
      // Get file details
      const file = req.file;
      const filename = file.originalname;
      const fileType = path.extname(filename).substring(1).toLowerCase();
      const fileSize = file.size;
      
      // Create file URL (in a production environment, this would be a CDN or storage URL)
      const fileUrl = `/uploads/${file.filename}`;
      
      // Save resource to database
      const resource = await storage.createResource({
        name: filename,
        type: fileType,
        size: fileSize,
        url: fileUrl,
        uploadedBy: req.user.id,
        groupId: parseInt(groupId)
      });
      
      // Create activity record
      const group = await storage.getStudyGroup(parseInt(groupId));
      if (group) {
        await storage.createActivity({
          userId: req.user.id,
          description: `Uploaded a file: <span class="font-medium">${filename}</span> to ${group.name} group`,
          icon: "upload_file",
          iconColor: "primary",
          relatedId: resource.id,
          relatedType: "resource"
        });

        // Create notifications for group members
        const groupMembers = await storage.getGroupMembers(parseInt(groupId));
        for (const member of groupMembers) {
          if (member.userId !== req.user.id) {
            await storage.createNotification({
              userId: member.userId,
              title: "New resource uploaded",
              message: `${req.user.username} uploaded ${filename} to ${group.name} group`,
              type: "info",
              icon: "upload_file",
              relatedId: resource.id,
              relatedType: "resource",
              unread: true
            });
          }
        }
      }
      
      res.status(201).json(resource);
    } catch (error) {
      console.error('File upload error:', error);
      res.status(500).json({ message: "Failed to upload resource" });
    }
  });

  // Sessions API
  app.get("/api/sessions/upcoming", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const sessions = await storage.getUpcomingSessions(req.user.id);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch upcoming sessions" });
    }
  });

  app.post("/api/sessions", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      if (req.user.role !== "teacher") {
        return res.status(403).json({ message: "Only teachers can create study sessions" });
      }
      
      // Ensure proper types for nullable fields
      const sessionData = {
        ...req.body,
        hostId: req.user.id,
        description: req.body.description || null,
        meetingUrl: req.body.meetingUrl || null,
        status: req.body.status || "scheduled",
      };
      
      const validatedData = insertSessionSchema.parse(sessionData);
      
      // Check if user is a member of the group
      const isMember = await storage.isGroupMember(req.user.id, validatedData.groupId);
      if (!isMember) {
        return res.status(403).json({ message: "You must be a member of this group to create sessions" });
      }
      
      const session = await storage.createSession(validatedData);
      
      // Create activity record
      const group = await storage.getStudyGroup(validatedData.groupId);
      if (group) {
        await storage.createActivity({
          userId: req.user.id,
          description: `Scheduled a new session: <span class="font-medium">${session.title}</span> for ${group.name} group`,
          icon: "event_available",
          iconColor: "info",
          relatedId: session.id,
          relatedType: "session"
        });
      
        // Create notifications for group members
        const groupMembers = await storage.getGroupMembers(validatedData.groupId);
        const sessionDate = new Date(validatedData.date).toLocaleString();
      
        for (const member of groupMembers) {
          if (member.userId !== req.user.id) {
            await storage.createNotification({
              userId: member.userId,
              title: "New study session scheduled",
              message: `${session.title} - ${sessionDate}`,
              type: "info",
              icon: "event",
              relatedId: session.id,
              relatedType: "session",
              unread: true
            });
          }
        }
      }
      
      res.status(201).json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create session" });
    }
  });

  app.post("/api/sessions/:id/join", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const sessionId = parseInt(req.params.id);
      if (isNaN(sessionId)) {
        return res.status(400).json({ message: "Invalid session ID" });
      }
      
      // Check if session exists
      const session = await storage.getSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      
      // Check if user is a member of the related group
      const isMember = await storage.isGroupMember(req.user.id, session.groupId);
      if (!isMember) {
        return res.status(403).json({ message: "You must be a member of the related group to join this session" });
      }
      
      // Check if user is already a participant
      const isParticipant = await storage.isSessionParticipant(sessionId, req.user.id);
      if (isParticipant) {
        return res.status(400).json({ message: "You are already a participant in this session" });
      }
      
      await storage.addSessionParticipant({
        sessionId,
        userId: req.user.id,
        status: "confirmed"
      });
      
      // Notify the host
      await storage.createNotification({
        userId: session.hostId,
        title: "New session participant",
        message: `${req.user.username} joined your ${session.title} session`,
        type: "info",
        icon: "person_add",
        relatedId: sessionId,
        relatedType: "session",
        unread: true
      });
      
      res.status(200).json({ message: "Successfully joined session" });
    } catch (error) {
      res.status(500).json({ message: "Failed to join session" });
    }
  });

  // Notifications API
  app.put("/api/user/profile", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const { username, email } = req.body;
    if (!username || !email) {
      return res.status(400).json({ message: "Username and email are required" });
    }

    await storage.updateUserProfile(req.user.id, { username, email });
    res.json({ message: "Profile updated successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to update profile" });
  }
});

app.get("/api/notifications", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const notifications = await storage.getUserNotifications(req.user.id);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post("/api/notifications/:id/read", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const notificationId = parseInt(req.params.id);
      if (isNaN(notificationId)) {
        return res.status(400).json({ message: "Invalid notification ID" });
      }
      
      // Check if notification belongs to user
      const notification = await storage.getNotification(notificationId);
      if (!notification || notification.userId !== req.user.id) {
        return res.status(403).json({ message: "Notification not found or access denied" });
      }
      
      await storage.markNotificationAsRead(notificationId);
      res.status(200).json({ message: "Notification marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Activities API
  app.get("/api/activities", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const activities = await storage.getUserRelevantActivities(req.user.id);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  return httpServer;
}
