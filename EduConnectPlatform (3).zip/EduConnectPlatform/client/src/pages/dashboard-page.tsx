import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import Layout from '@/components/layout/Layout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';
import { Loader2, Plus, TrendingUp, Clock } from 'lucide-react';
import { getQueryFn } from '@/lib/queryClient';

export default function DashboardPage() {
  const { user } = useAuth();
  
  // Fetch study groups
  const { data: studyGroups, isLoading: loadingGroups } = useQuery({
    queryKey: ['/api/study-groups'],
    queryFn: getQueryFn({ on401: "throw" }),
  });
  
  // Fetch upcoming sessions
  const { data: upcomingSessions, isLoading: loadingSessions } = useQuery({
    queryKey: ['/api/sessions/upcoming'],
    queryFn: getQueryFn({ on401: "throw" }),
  });
  
  // Fetch activities
  const { data: recentActivities, isLoading: loadingActivities } = useQuery({
    queryKey: ['/api/activities'],
    queryFn: getQueryFn({ on401: "throw" }),
  });
  
  // Fetch notifications
  const { data: notifications, isLoading: loadingNotifications } = useQuery({
    queryKey: ['/api/notifications'],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  const isTeacher = user?.role === 'teacher';

  return (
    <Layout title="Dashboard">
      <div className="max-w-7xl mx-auto space-y-6 pb-20">
        {/* Welcome Section */}
        <Card className="slide-in">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div>
                <h2 className="font-heading text-2xl font-semibold">Welcome back, {user?.username}!</h2>
                <CardDescription className="mt-1">
                  Here's what's happening in your EduConnect world today.
                </CardDescription>
              </div>
              {isTeacher && (
                <div className="mt-4 md:mt-0">
                  <Button className="flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>Create Study Group</span>
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="fade-in">
            <CardContent className="pt-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-neutral-500 text-sm">Active Study Groups</p>
                  <h3 className="text-3xl font-medium mt-1">
                    {loadingGroups ? <Loader2 className="h-8 w-8 animate-spin" /> : studyGroups?.length || 0}
                  </h3>
                </div>
                <div className="bg-primary/10 p-2 rounded-md">
                  <span className="material-icons text-primary">groups</span>
                </div>
              </div>
              <div className="mt-4 text-xs flex items-center text-green-600">
                <TrendingUp className="mr-1 h-4 w-4" />
                <span>12% increase this month</span>
              </div>
            </CardContent>
          </Card>

          <Card className="fade-in">
            <CardContent className="pt-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-neutral-500 text-sm">Upcoming Sessions</p>
                  <h3 className="text-3xl font-medium mt-1">
                    {loadingSessions ? <Loader2 className="h-8 w-8 animate-spin" /> : upcomingSessions?.length || 0}
                  </h3>
                </div>
                <div className="bg-amber-500/10 p-2 rounded-md">
                  <span className="material-icons text-amber-500">event</span>
                </div>
              </div>
              <div className="mt-4 text-xs flex items-center text-green-600">
                <Clock className="mr-1 h-4 w-4" />
                <span>Next session in 2 hours</span>
              </div>
            </CardContent>
          </Card>

          <Card className="fade-in">
            <CardContent className="pt-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-neutral-500 text-sm">New Messages</p>
                  <h3 className="text-3xl font-medium mt-1">
                    {loadingNotifications ? <Loader2 className="h-8 w-8 animate-spin" /> : notifications?.length || 0}
                  </h3>
                </div>
                <div className="bg-blue-500/10 p-2 rounded-md">
                  <span className="material-icons text-blue-500">forum</span>
                </div>
              </div>
              <div className="mt-4 text-xs flex items-center text-green-600">
                <span className="material-icons text-sm mr-1">notifications</span>
                <span>3 unread from Mathematics</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Your Study Groups */}
        <Card className="slide-in">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Your Study Groups</CardTitle>
              <Link href="/study-groups">
                <Button variant="ghost" className="text-primary hover:text-primary/80 text-sm flex items-center">
                  <span>View All</span>
                  <span className="material-icons text-sm ml-1">arrow_forward</span>
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {loadingGroups ? (
              <div className="flex justify-center p-10">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {studyGroups?.length > 0 ? (
                  studyGroups.slice(0, 3).map((group) => (
                    <div key={group.id} className="border border-neutral-200 rounded-lg hover:shadow-md transition-shadow overflow-hidden">
                      <div className="h-32 overflow-hidden bg-gradient-to-br from-primary/10 to-accent/10 relative flex items-center justify-center">
                        <span className="material-icons text-5xl text-primary/80">
                          {group.subject?.toLowerCase().includes('math') ? 'functions' :
                           group.subject?.toLowerCase().includes('science') ? 'science' :
                           group.subject?.toLowerCase().includes('history') ? 'history_edu' :
                           group.subject?.toLowerCase().includes('language') ? 'translate' :
                           group.subject?.toLowerCase().includes('computer') ? 'computer' :
                           group.subject?.toLowerCase().includes('art') ? 'palette' :
                           group.subject?.toLowerCase().includes('music') ? 'music_note' :
                           'school'}
                        </span>
                        <div className="absolute top-2 right-2 bg-white bg-opacity-90 text-xs px-2 py-1 rounded-full">
                          <span className="text-primary font-medium">{group.memberCount || 0} members</span>
                        </div>
                      </div>
                      <div className="p-4">
                        <h4 className="font-medium">{group.name}</h4>
                        <p className="text-sm text-neutral-600 mt-1">{group.description}</p>
                        <div className="flex items-center mt-3 text-sm text-neutral-500">
                          <span className="material-icons text-xs mr-1">schedule</span>
                          <span>Next session: {group.nextSession || 'Not scheduled'}</span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-10 text-neutral-500">
                    <p>You haven't joined any study groups yet.</p>
                    <Link href="/study-groups">
                      <Button variant="link" className="mt-2">Browse available groups</Button>
                    </Link>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upcoming Sessions */}
        <Card className="slide-in">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Upcoming Sessions</CardTitle>
              {isTeacher && (
                <Button variant="outline" className="flex items-center text-sm">
                  <span>Schedule New</span>
                  <span className="material-icons text-sm ml-1">add</span>
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {loadingSessions ? (
              <div className="flex justify-center p-10">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                {upcomingSessions?.length > 0 ? (
                  <table className="min-w-full">
                    <thead>
                      <tr className="bg-neutral-50 text-left text-neutral-500 text-sm">
                        <th className="py-3 px-4 font-medium">Group</th>
                        <th className="py-3 px-4 font-medium">Date & Time</th>
                        <th className="py-3 px-4 font-medium">Duration</th>
                        <th className="py-3 px-4 font-medium">Platform</th>
                        <th className="py-3 px-4 font-medium">Status</th>
                        <th className="py-3 px-4 font-medium"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {upcomingSessions.map((session) => (
                        <tr key={session.id} className="border-t border-neutral-200">
                          <td className="py-3 px-4">
                            <div className="flex items-center">
                              <div className="w-8 h-8 rounded-full bg-primary-light flex items-center justify-center mr-3">
                                <span className="material-icons text-primary text-sm">{session.icon || 'groups'}</span>
                              </div>
                              <span>{session.groupName}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-sm">{session.dateTime}</td>
                          <td className="py-3 px-4 text-sm">{session.duration}</td>
                          <td className="py-3 px-4 text-sm">
                            <div className="flex items-center">
                              {session.platform === 'Google Meet' ? (
                                <img 
                                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Google_Meet_icon_%282020%29.svg/2491px-Google_Meet_icon_%282020%29.svg.png" 
                                  alt="Google Meet" 
                                  className="w-5 h-5 mr-2" 
                                />
                              ) : (
                                <img 
                                  src="https://logos-world.net/wp-content/uploads/2021/02/Zoom-Logo.png" 
                                  alt="Zoom" 
                                  className="w-12 h-5 mr-2" 
                                />
                              )}
                              {session.platform}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <Badge variant={session.status === 'Confirmed' ? 'success' : 'warning'}>
                              {session.status}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <Button variant="ghost" size="sm">
                              <span className="material-icons">more_vert</span>
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="text-center py-10 text-neutral-500">
                    <p>No upcoming sessions scheduled.</p>
                    {isTeacher && (
                      <Link href="/sessions">
                        <Button variant="link" className="mt-2">Schedule a session</Button>
                      </Link>
                    )}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity & Notifications */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Recent Activity */}
          <div className="md:col-span-2">
            <Card className="slide-in h-full">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingActivities ? (
                  <div className="flex justify-center p-10">
                    <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentActivities?.length > 0 ? (
                      recentActivities.map((activity) => (
                        <div key={activity.id} className="flex items-start space-x-3 pb-4 border-b border-neutral-200">
                          <div className={`bg-${activity.iconColor || 'primary'}-100 rounded-full p-2 mt-1`}>
                            <span className={`material-icons text-${activity.iconColor || 'primary'} text-sm`}>
                              {activity.icon || 'info'}
                            </span>
                          </div>
                          <div>
                            <p className="text-sm" dangerouslySetInnerHTML={{ __html: activity.description }}></p>
                            <p className="text-xs text-neutral-500 mt-1">{activity.timestamp}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-10 text-neutral-500">
                        <p>No recent activities.</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Notifications */}
          <div>
            <Card className="slide-in h-full">
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingNotifications ? (
                  <div className="flex justify-center p-10">
                    <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {notifications?.length > 0 ? (
                      notifications.map((notification) => (
                        <div 
                          key={notification.id} 
                          className={`flex items-start space-x-3 pb-4 border-b border-neutral-200 ${
                            notification.unread ? 'bg-primary bg-opacity-5 p-2 rounded-md' : ''
                          }`}
                        >
                          <div className={`bg-${notification.type || 'primary'}-100 rounded-full p-2 mt-1`}>
                            <span className={`material-icons text-${notification.type || 'primary'} text-sm`}>
                              {notification.icon || 'notifications'}
                            </span>
                          </div>
                          <div>
                            <p className="text-sm font-medium">{notification.title}</p>
                            <p className="text-xs mt-1">{notification.message}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-10 text-neutral-500">
                        <p>No new notifications.</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
